import React, { useMemo, useState } from 'react'
import { useTable, useGlobalFilter, useFilters, useSortBy } from 'react-table'
import './table.css'
import { GlobalFilter } from './GlobalFilter'
import { ColumnFilter } from './ColumnFilter'
import VerticalAlignTopIcon from '@mui/icons-material/VerticalAlignTop';
import VerticalAlignBottomIcon from '@mui/icons-material/VerticalAlignBottom';
import SwapVertSharpIcon from '@mui/icons-material/SwapVertSharp';
import TablePagination from '@mui/material/TablePagination';
/* import { Checkbox } from './Checkbox' */
export function DataTable({ columnsData, rowsData }) {

  const columns = useMemo(() => columnsData, [])
  const data = useMemo(() => rowsData, [])
  const defaultColumn = useMemo(() => { return { Filter: ColumnFilter } }, [])

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  }
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const { getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    state,
    setGlobalFilter,
    prepareRow,
    allColumns,
    getToggleHideAllColumnsProps } = useTable({ columns: columns, data: data, defaultColumn }, useFilters, useGlobalFilter, useSortBy)

  const { globalFilter } = state

  return (
    <>
      {/* uncomment after adding checkbox code
      <div>
        <div>
          <Checkbox {...getToggleHideAllColumnsProps()} />Toggle All
        </div>
        {
          allColumns.map(column => (
            <div key={column.id}>
              <label>
                <input type="checkbox" {...column.getToggleHiddenProps()} />
                {column.Header}
              </label>
            </div>
          ))
        } */}
        <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
      {/* </div> */}
      <table{...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr{...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th{...column.getHeaderProps(column.getSortByToggleProps())}>
                  {column.render('Header')}
                  <span>
                    {column.isSorted ? (column.isSortedDesc ? <VerticalAlignBottomIcon /> : <VerticalAlignTopIcon />) : <SwapVertSharpIcon />}
                  </span>
                  <div>{column.canFilter ? column.render('Filter') : null}</div></th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody{...getTableBodyProps()}>
          {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
            prepareRow(row)
            return (
              <tr{...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return <td style={{border:"none"}} {...cell.getCellProps()}>{cell.render('Cell') }</td>
                })}
              </tr>
            )
          })}
        </tbody>

        {/* uncomment if you want to see header at footer section also <tfoot>
          {footerGroups.map((footerGroup) => (
            <tr{...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map((column) => (
                <td{...column.getFooterProps()}>{column.render('Footer')}</td>
              ))}
            </tr>
          ))}
        </tfoot> */}
      </table><div></div>
      <TablePagination
        rowsPerPageOptions={[5, 10, 15, 20, 50, 100]}
        component="div"
        count={data.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>
  );
}
