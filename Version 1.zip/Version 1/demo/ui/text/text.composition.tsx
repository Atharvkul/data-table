import React from 'react';
import { Text } from './text';

export const BasicText = () => <Text text="hello from Text" />;
