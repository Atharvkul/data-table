import { MyReactAspect } from './my-react.aspect';

export type { MyReactMain } from './my-react.main.runtime';
export default MyReactAspect;
export { MyReactAspect };
