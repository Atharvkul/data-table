import React, { useEffect, useMemo, useState, Fragment } from "react";
import { useTable, useGlobalFilter, useFilters, useSortBy, useRowSelect } from "react-table";
import "./table.css";
import { ColumnFilter } from "./ColumnFilter";
import SouthIcon from "@mui/icons-material/South";
import NorthIcon from "@mui/icons-material/North";
import SwapVertIcon from "@mui/icons-material/SwapVert";
import TablePagination from "@mui/material/TablePagination";
import { Checkbox } from "./Checkbox";
import Menu from "@mui/material/Menu";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import PopupState, { bindTrigger, bindMenu } from "material-ui-popup-state";
import { BrowserRouter as Router, Link, Route, Switch } from "react-router-dom";
import ReactTooltip from 'react-tooltip';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
export function DataTable({ columnData, rowData, pageSizes, tableTitle, exportTable }) {

  const [columnsData, setColumnsData] = useState(columnData)
  const [rowsData, setRowsData] = useState(rowData)

  const EditableCell = ({
    value: initialValue,
    row: { index },
    column: { id },

    // This is a custom function that we supplied to our table instance
  }) => {
    // We need to keep and update the state of the cell normally
    const [value, setValue] = React.useState(initialValue);

    // If the initialValue is changed external, sync it up with our state
    useEffect(() => {
      { typeof (value) !== 'undefined' && typeof (value) === 'object' ? setValue(value[0]) : setValue(value) }
    }, [initialValue]);

    return (
      value
    );
  };
  const columns = useMemo(() => columnsData, []);
  const [data, setData] = useState(useMemo(() => rowsData, []))
  const defaultColumn = useMemo(() => {
    return { Filter: ColumnFilter, Cell: EditableCell };
  }, []);
  // Let's add a data resetter/randomizer to help
  // illustrate that flow...

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    state,
    setGlobalFilter,
    prepareRow,
    allColumns,
    getToggleHideAllColumnsProps,
    selectedFlatRows,
  } = useTable(
    {
      columns: columns,
      data: data,
      defaultColumn,
    },
    useFilters,
    useGlobalFilter,
    useSortBy,
    useRowSelect,
    (hooks) => {
      hooks.visibleColumns.push((columns) => {
        return [
          {
            id: "selection",
            Header: ({ getToggleAllRowsSelectedProps }) => (
              <Checkbox {...getToggleAllRowsSelectedProps()} style={{ marginBottom: "10px" }} />
            ),
            Cell: ({ row }) => (
              <Checkbox {...row.getToggleRowSelectedProps()} />
            ),
          },
          ...columns,
        ];
      });
    }
  );

  const handleDeleteClick = (deleteRow) => {
    const dataArray = [...data]
    dataArray.splice(deleteRow.index, 1);
    setData(dataArray)
  }

  return (
    <><div className="header-section">
      <span >
        {tableTitle ? <h1>{tableTitle}</h1> : null}</span>
      <span style={{ display: "flex", marginRight: "30px", alignItems: "center" }}>
        {exportTable ? <ReactHTMLTableToExcel
          className="export-button"
          table="table-xls"
          filename="ReportExcel"
          sheet="Sheet"
          buttonText="Export excel" /> : null}
      </span>
    </div>
      <div className="table-container">
        <table id="table-xls" {...getTableProps()} >
          <span>
            {/* Header Content Displayed */}
            <thead>
              {headerGroups.map((headerGroup) => (
                <tr{...headerGroup.getHeaderGroupProps()}>
                  {headerGroup.headers.map((column) => (
                    <th{...column.getHeaderProps()} style={{ padding: "10px 15px 10px 15px" }}>
                      <div className="header-container">
                        <div className="align-header">{column.render('Header')}</div>
                        <div className="sort-filter-container">
                          {column.id !== 'selection' ?
                            <span {...column.getHeaderProps(column.getSortByToggleProps())}>
                              {column.isSorted ? (column.isSortedDesc ? <SouthIcon style={{ width: "18px", height: "18px", color: "#666" }} /> : <NorthIcon style={{ width: "18px", height: "18px", color: "#666" }} />) : <SwapVertIcon style={{ width: "18px", height: "18px", color: "#666" }} />}
                            </span> : null}

                          <PopupState variant="popover" popupId="demo-popup-menu">
                            {(popupState) => (
                              <React.Fragment>
                                <button  {...bindTrigger(popupState)} className="header-options">
                                  <MoreVertIcon style={{ width: "18px", height: "18px", color: "#666" }} />
                                </button>
                                <Menu {...bindMenu(popupState)}>
                                  <div style={{ paddingLeft: "15px" }}>Column's</div>
                                  {
                                    allColumns.map(column => (
                                      <div key={column.id} style={{ padding: "0 20px 0 20px" }}>
                                        <label>
                                          <input type="checkbox" {...column.getToggleHiddenProps()} />
                                          {column.Header}
                                        </label>
                                      </div>
                                    ))
                                  }
                                </Menu>
                              </React.Fragment>
                            )}
                          </PopupState>
                        </div>
                      </div>
                      <div>{column.canFilter ? column.render('Filter') : null}</div>
                    </th>))}
                  <th style={{ padding: "10px 15px 10px 15px", color: "#666", fontSize: " 14px" }}>
                    Actions
                  </th>
                </tr>
              ))}
            </thead>
            {/* Table rows Displayed */}
            <tbody {...getTableBodyProps()} style={{ borderBottom: "1px solid #bbbbbb" }}>
              {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row) => {
                  prepareRow(row)
                  return (
                    <tr {...row.getRowProps()}>
                      {row.cells.map((cell) => {
                        const cellKey = (cell.getCellProps().key)
                        let cellValue = cell.value
                        let r = () => Math.random() * 256 >> 0;
                        let randomColor = `${r()}, ${r()}, ${r()}`;
                        return (

                          <td style={{ border: "none", alignItems:"center"}}{...cell.getCellProps()}>
                            <span style={{display:"flex", justifyContent:"space-between"}}>
                            <span>
                            {typeof (cellValue) !== 'undefined' ?
                              <span className="character-display" style={{ backgroundColor: "rgb(" + randomColor + " ,0.1)", color: "rgb(" + randomColor + ",1)" }}>
                                {cellValue === 'object' ? cellValue[0].toString().charAt(0) : cellValue.toString().charAt(0)}</span>
                              : null}
                            
                            <span className={(columnsData.find(column => column.decorate && cellKey.includes(column.accessor) != '') ?
                                "blue-color" : "black-color")}>
                              {typeof (cellValue) !== 'undefined' && typeof (cellValue) === 'object' ? cell.render("Cell") : cell.render("Cell")}
                            </span>
                            </span>
                            {typeof (cellValue) !== 'undefined' &&
                              cellValue.toString().split(',').length > 1 ?
                              <>
                                <span style={{marginTop: "-5px"}}className="blue-color" data-tip={cellValue.toString().split(',').slice(1).toString()}>
                                  {"+" + (cellValue.toString().split(',').length - 1).toString()}
                                </span>
                                <ReactTooltip place="bottom" type="dark" effect="solid" />
                              </> : null}
                              </span>
                          </td>
                        )

                      })}
                      {/* Actions Button  */}
                      <div style={{ margin: "5px 0 0 20px" }}>
                        <PopupState variant="popover" popupId="demo-popup-menu">
                          {(popupState) => (
                            <React.Fragment>
                              <button  {...bindTrigger(popupState)} className="header-options">
                                <MoreVertIcon style={{ width: "18px", height: "18px" }} />
                              </button>
                              <Menu {...bindMenu(popupState)}>
                                <div style={{ width: "100px", display: "flex", flexDirection: "column" }}>
                                  <button className="update-delete" onClick={() => { handleDeleteClick(row) }}>Delete</button>
                                </div>
                              </Menu>
                            </React.Fragment>
                          )}
                        </PopupState>
                      </div>
                    </tr>
                  )
                }
                )
              }
            </tbody>
          </span>
        </table>
      </div >

      <TablePagination
        rowsPerPageOptions={pageSizes}
        component="div"
        count={data.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>
  );
}