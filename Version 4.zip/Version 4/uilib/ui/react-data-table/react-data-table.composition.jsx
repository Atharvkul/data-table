import React from 'react';
import { ReactDataTable } from './react-data-table';

export const BasicReactDataTable = () => (
  <ReactDataTable columnData={[
    { Header: "id", accessor: "id" },
    { Header: "First Name", accessor: "first_name", initialDecorate: true },
    { Header: "Last Name", accessor: "last_name", routing: true, routeLink: "https://www.google.com" },
    { Header: "email", accessor: "email" },
    { Header: "Gender", accessor: "gender", routing: true, routeLink: "https://www.google.com" },
    { Header: "Login Date", accessor: "login_date", decorate: true },
    { Header: "Age", accessor: "age", routing: true, routeLink: "https://www.google.com" },
  ]}

    rowData={[{ id: 1, first_name: "Goldy", last_name: "Richardes", email: "grichardes0@sourceforge.net", gender: "Polygender", login_date: "12/26/2020", age: 14 },
    { id: 2, first_name: ["Benni", "Atharv"], last_name: "Lefeaver", email: "blefeaver1@bloomberg.com", gender: "Male", login_date: "5/14/2020", age: 64 },
    { id: 3, first_name: "Glynn", last_name: "Tebbut", email: "gtebbut2@studiopress.com", gender: "Male", login_date: "11/6/2020", age: 95 },
    { id: 4, first_name: "Lorie", last_name: "Vivian", email: "lvivian3@cargocollective.com", gender: "Male", login_date: "8/22/2020", age: 56 },
    { id: 5, first_name: "Jamison", last_name: "Crammy", email: "jcrammy4@zdnet.com", gender: "Non-binary", login_date: "5/25/2020", age: 52 },
    { id: 6, first_name: "Delora", last_name: "McNabb", email: "dmcnabb5@techcrunch.com", gender: "Agender", login_date: "5/3/2020", age: 91 },
    { id: 7, first_name: "Caspar", last_name: "Philpot", email: "cphilpot6@accuweather.com", gender: "Agender", login_date: "8/8/2020", age: 77 },
    { id: 8, first_name: "Bayard", last_name: "Driscoll", email: "bdriscoll7@answers.com", gender: "Genderfluid", login_date: "10/25/2020", age: 27 },
    { id: 9, first_name: "Jonas", last_name: "Roelofs", email: "jroelofs8@nifty.com", gender: "Polygender", login_date: "12/19/2019", age: 10 },
    { id: 10, first_name: "Valeria", last_name: "Connolly", email: "vconnolly9@dedecms.com", gender: "Genderqueer", login_date: "6/9/2020", age: 28 },
    { id: 11, first_name: "Gwendolin", last_name: "Antushev", email: "gantusheva@photobucket.com", gender: "Polygender", login_date: "3/31/2021", age: 97 },
    { id: 12, first_name: "Abbey", last_name: "Gilleson", email: "agillesonb@salon.com", gender: "Male", login_date: "1/27/2020", age: 66 },
    { id: 13, first_name: "Sarah", last_name: "Blanking", email: "sblankingc@angelfire.com", gender: "Non-binary", login_date: "2/24/2020", age: 59 },
    { id: 14, first_name: "Willie", last_name: "Schaffler", email: "wschafflerd@tumblr.com", gender: "Genderfluid", login_date: "8/2/2021", age: 78 },
    { id: 15, first_name: "Addia", last_name: "Myrtle", email: "amyrtlee@cocolog-nifty.com", gender: "Female", login_date: "11/27/2020", age: 83 },
    { id: 16, first_name: "Kaitlynn", last_name: "William", email: "kwilliamf@microsoft.com", gender: "Genderfluid", login_date: "3/12/2021", age: 82 },
    { id: 17, first_name: "Catlee", last_name: "Andrews", email: "candrewsg@chron.com", gender: "Bigender", login_date: "3/13/2020", age: 49 },
    { id: 18, first_name: "Gothart", last_name: "Fitzsymonds", email: "gfitzsymondsh@bizjournals.com", gender: "Non-binary", login_date: "6/21/2020", age: 14 },
    { id: 19, first_name: "Harmony", last_name: "Deely", email: "hdeelyi@google.com.br", gender: "Genderqueer", login_date: "12/13/2019", age: 14 },
    { id: 20, first_name: "Miltie", last_name: "Newiss", email: "mnewissj@intel.com", gender: "Female", login_date: "6/20/2020", age: 49 }]}

    pageSizes={[5, 10, 15, 20, 50, 100]} tableTitle="Sample Title" exportTable
  />

);
