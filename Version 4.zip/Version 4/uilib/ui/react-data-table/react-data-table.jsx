import React, { useEffect, useMemo, useState, Fragment } from "react";
import { useTable, useGlobalFilter, useFilters, useSortBy, useRowSelect } from "react-table";
import "./table.css";
import { ColumnFilter } from "./ColumnFilter";
import SouthIcon from "@mui/icons-material/South";
import NorthIcon from "@mui/icons-material/North";
import SwapVertIcon from "@mui/icons-material/SwapVert";
import TablePagination from "@mui/material/TablePagination";
import { Checkbox } from "./Checkbox";
import Menu from "@mui/material/Menu";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import PopupState, { bindTrigger, bindMenu } from "material-ui-popup-state";
import DeleteIcon from '@mui/icons-material/Delete';
import ReactTooltip from 'react-tooltip';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import EditOffIcon from '@mui/icons-material/EditOff';

export function ReactDataTable({ columnData, rowData, pageSizes, tableTitle, exportTable }) {

  const [columnsData, setColumnsData] = useState(columnData)
  const [rowsData, setRowsData] = useState(rowData)

  const EditableCell = ({
    value: initialValue,
    row: { index },
    column: { id },

    // This is a custom function that we supplied to our table instance
  }) => {
    // We need to keep and update the state of the cell normally
    const [value, setValue] = React.useState(initialValue);

    // If the initialValue is changed external, sync it up with our state
    useEffect(() => {
      { typeof (value) !== 'undefined' && typeof (value) === 'object' ? setValue(value[0]) : setValue(value) }
    }, [initialValue]);

    if(value!==null || 'undefined')
      return value
      else
      return null
  };
  const columns = useMemo(() => columnsData, []);
  const [data, setData] = useState(useMemo(() => rowsData, []))
  const defaultColumn = useMemo(() => {
    return { Filter: ColumnFilter, Cell: EditableCell };
  }, []);
  // Let's add a data resetter/randomizer to help
  // illustrate that flow...
  const [disableEdit, setDisableEdit] = useState(false)
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    state,
    setGlobalFilter,
    prepareRow,
    allColumns,
    getToggleHideAllColumnsProps,
    selectedFlatRows,
  } = useTable(
    {
      columns: columns,
      data: data,
      defaultColumn,
    },
    useFilters,
    useGlobalFilter,
    useSortBy,
    useRowSelect,
    (hooks) => {
      hooks.visibleColumns.push((columns) => {
        return [
          {
            id: "selection",
            Header: ({ getToggleAllRowsSelectedProps }) => (
              <Checkbox {...getToggleAllRowsSelectedProps()} style={{ margin: "30px 0 0 0" }} />
            ),
            Cell: ({ row }) => (
              <Checkbox {...row.getToggleRowSelectedProps()} />
            ),
          },
          ...columns,
        ];
      });
    }
  );

  const handleDeleteClick = (deleteRow) => {
    const dataArray = [...data]
    dataArray.splice(deleteRow.index, 1);
    setData(dataArray)
  }

  return (
    <><div className="header-section">
      <span >
        {tableTitle ? <h1>{tableTitle}</h1> : null}</span>
      <span style={{ display: "flex", marginRight: "30px", alignItems: "center" }}>
        {exportTable ? <ReactHTMLTableToExcel
          className="export-button"
          table="table-xls"
          filename="ReportExcel"
          sheet="Sheet"
          buttonText="Export excel" /> : null}
      </span>
    </div>
    <div style={{display:"flex", width: "100%", justifyContent:"flex-end"}}>
    {disableEdit?<button style={{minWidth: "130px", margin: "10px 30px 10px 0"}}className="export-button" onClick={()=>{setDisableEdit(false)}}>Enable Actions</button>:null}
    </div>
      <div className="table-container">
        <table id="table-xls" {...getTableProps()} >
          <span>
            {/* Header Content Displayed */}
            <thead>
              {headerGroups.map((headerGroup) => (
                <tr{...headerGroup.getHeaderGroupProps()}>
                  {headerGroup.headers.map((column) => (
                    <th{...column.getHeaderProps()} style={{ padding: "10px 15px 10px 15px" }}>
                      <div className="header-container">
                        <div className="align-header">{column.render('Header')}</div>
                        <div className="sort-filter-container">
                          {column.id !== 'selection' ?
                            <span {...column.getHeaderProps(column.getSortByToggleProps())}>
                              {column.isSorted ? (column.isSortedDesc ? <SouthIcon style={{ width: "18px", height: "18px", color: "#666" }} /> : <NorthIcon style={{ width: "18px", height: "18px", color: "#666" }} />) : <SwapVertIcon style={{ width: "18px", height: "18px", color: "#666" }} />}
                            </span> : null}
                           {column.id !=='selection'? 
                          <PopupState variant="popover" popupId="demo-popup-menu">
                            {(popupState) => (
                              <React.Fragment>
                                <button  {...bindTrigger(popupState)} className="header-options">
                                  <MoreVertIcon style={{ width: "18px", height: "18px", color: "#666" }} />
                                </button>
                                <Menu {...bindMenu(popupState)}>
                                  <div style={{ paddingLeft: "15px" }}>Column's</div>
                                  {
                                    allColumns.map(column => (
                                      <div key={column.id} style={{ padding: "0 20px 0 20px" }}>
                                        <label>
                                          <input type="checkbox" {...column.getToggleHiddenProps()} />
                                          {column.Header}
                                        </label>
                                      </div>
                                    ))
                                  }
                                </Menu>
                              </React.Fragment>
                            )}
                          </PopupState>:null}
                        </div>
                      </div>
                      <div>
                        {column.canFilter ? column.render('Filter') : null}</div>
                    </th>))}
                  {disableEdit!==true?<th style={{ padding: "10px 15px 10px 15px", color: "#666", fontSize: " 14px" }}>
                    Actions
                    <EditOffIcon style={{ width: "18px", height: "18px", marginTop: "10px"}}className="edit-button" onClick={()=>{setDisableEdit(true)}}/>
                  </th>:null}
                </tr>
              ))}
            </thead>
            {/* Table rows Displayed */}
            <tbody {...getTableBodyProps()} style={{ borderBottom: "1px solid #bbbbbb" }}>
              {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row) => {
                  prepareRow(row)
                  return (
                    <tr {...row.getRowProps()}>
                      {row.cells.map((cell) => {
                        const cellKey = (cell.getCellProps().key).toString()
                        let cellValue = cell.value
                        let r = () => Math.random() * 256 >> 0;
                        let randomColor = `${r()}, ${r()}, ${r()}`;
                        return (
                          <td style={{ border: "none", alignItems: "center" }}{...cell.getCellProps()}>

                            <span style={{ display: "flex", justifyContent: "space-between" }}>
                              <span>
                                { typeof (cellValue) !== 'undefined' && (columnsData.find(column => column.initialDecorate && cellKey.includes(column.accessor) != '')?
                                  <span className="character-display" style={{ backgroundColor: "rgb(" + randomColor + " ,0.1)", color: "rgb(" + randomColor + ",1)" }}>
                                    {cellValue === 'object' ? cellValue[0].toString().charAt(0) : cellValue.toString().charAt(0)}</span>
                                  : null)}
                                <span className={columnsData.find(column => column.decorate && cellKey.includes(column.accessor) != '') ?
                                  "blue-color" : 
                                  columnsData.find(column => column.routing && cellKey.includes(column.accessor) != '') ?
                                  "routing-data":"black-color"}
                                  onClick={() =>(columnsData.find(column => (column.routeLink && cellKey.includes(column.accessor) != '') ? window.location.href=column.routeLink : console.log("Nothing") ))}
                                >
                                  {typeof (cellValue) !== 'undefined' && typeof (cellValue) === 'object' ? cell.render("Cell") : cell.render("Cell")}
                                </span>
                              </span>
                              {typeof (cellValue) !== 'undefined' &&
                                cellValue.toString().split(',').length > 1 ?
                                <>
                                  <span style={{ marginTop: "-5px" }} className="blue-color" data-tip={cellValue.toString().split(',').slice(1).toString()}>
                                    {"+" + (cellValue.toString().split(',').length - 1).toString()}
                                  </span>
                                  <ReactTooltip place="bottom" type="dark" effect="solid" />
                                </> : null}
                            </span>
                          </td>)
                      })}
                      {/* Actions Button  */}
                      {disableEdit!==true?
                      <div style={{ margin: "5px 0 0 20px" }}>
                                <div style={{ width: "50px", display: "flex", flexDirection: "column" }}>
                                  <button className="update-delete" onClick={() => { handleDeleteClick(row) }}><DeleteIcon style={{color: "#666", width: "18px", height: "18px"}}/></button>
                                </div>
                      </div>:null}
                    </tr>
                  )
                }
                )
              }
            </tbody>
          </span>
        </table>
      </div >

      <TablePagination
        rowsPerPageOptions={pageSizes}
        component="div"
        count={data.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>
  );
}