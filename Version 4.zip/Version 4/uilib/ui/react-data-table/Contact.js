import React from 'react'

const Contact = () => {
    return (
        <div>
            COntact Page
        </div>
    )
}

export default Contact
