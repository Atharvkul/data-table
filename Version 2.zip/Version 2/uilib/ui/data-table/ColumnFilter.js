import React from 'react'
import SearchIcon from '@mui/icons-material/Search';
import './table.css'
export const ColumnFilter = ({ column }) => {
    const { filterValue, setFilter } = column
    return (
        <div className="header-container brdr">
            
                <input value={filterValue || ''} className="column-filter" placeholder="Search" onChange={(e) => { setFilter(e.target.value) }} />
                <SearchIcon style={{color:"grey"}}/>
            
        </div>
    )
}
