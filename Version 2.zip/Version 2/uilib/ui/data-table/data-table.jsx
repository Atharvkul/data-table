import React, { useMemo, useState } from 'react'
import { useTable, useGlobalFilter, useFilters, useSortBy, useRowSelect } from 'react-table'
import './table.css'
import { ColumnFilter } from './ColumnFilter'
import SouthIcon from '@mui/icons-material/South'
import NorthIcon from '@mui/icons-material/North'
import SwapVertIcon from '@mui/icons-material/SwapVert';
import TablePagination from '@mui/material/TablePagination'
import { Checkbox } from './Checkbox'
import Menu from '@mui/material/Menu'
import MoreVertIcon from '@mui/icons-material/MoreVert'
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state'
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import NativeSelect from '@mui/material/NativeSelect';
import TextField from '@mui/material/TextField';

export function DataTable({ /* columnsData, rowsData, pageSizes, tableTitle */ }) {
  columnsData = [
    { Header: 'id', Footer: 'id', accessor: 'id' },
    { Header: 'First Name', Footer: 'First Name', accessor: 'first_name' },
    { Header: 'Last Name', Footer: 'Last Name', accessor: 'last_name' },
    { Header: 'email', Footer: 'email', accessor: 'email' },
    { Header: 'Gender', Footer: 'Gender', accessor: 'gender' },
    { Header: 'Login Date', Footer: 'Login Date', accessor: 'login_date' },
    { Header: 'Age', Footer: 'Age', accessor: 'age' }]

  rowsData = [{ id: 1, first_name: "Goldy", last_name: "Richardes", email: "grichardes0@sourceforge.net", gender: "Polygender", login_date: "12/26/2020", age: 14 },
  { id: 2, first_name: "Benni", last_name: "Lefeaver", email: "blefeaver1@bloomberg.com", gender: "Male", login_date: "5/14/2020", age: 64 },
  { id: 3, first_name: "Glynn", last_name: "Tebbut", email: "gtebbut2@studiopress.com", gender: "Male", login_date: "11/6/2020", age: 95 },
  { id: 4, first_name: "Lorie", last_name: "Vivian", email: "lvivian3@cargocollective.com", gender: "Male", login_date: "8/22/2020", age: 56 },
  { id: 5, first_name: "Jamison", last_name: "Crammy", email: "jcrammy4@zdnet.com", gender: "Non-binary", login_date: "5/25/2020", age: 52 },
  { id: 6, first_name: "Delora", last_name: "McNabb", email: "dmcnabb5@techcrunch.com", gender: "Agender", login_date: "5/3/2020", age: 91 },
  { id: 7, first_name: "Caspar", last_name: "Philpot", email: "cphilpot6@accuweather.com", gender: "Agender", login_date: "8/8/2020", age: 77 },
  { id: 8, first_name: "Bayard", last_name: "Driscoll", email: "bdriscoll7@answers.com", gender: "Genderfluid", login_date: "10/25/2020", age: 27 },
  { id: 9, first_name: "Jonas", last_name: "Roelofs", email: "jroelofs8@nifty.com", gender: "Polygender", login_date: "12/19/2019", age: 10 },
  { id: 10, first_name: "Valeria", last_name: "Connolly", email: "vconnolly9@dedecms.com", gender: "Genderqueer", login_date: "6/9/2020", age: 28 },
  { id: 11, first_name: "Gwendolin", last_name: "Antushev", email: "gantusheva@photobucket.com", gender: "Polygender", login_date: "3/31/2021", age: 97 },
  { id: 12, first_name: "Abbey", last_name: "Gilleson", email: "agillesonb@salon.com", gender: "Male", login_date: "1/27/2020", age: 66 },
  { id: 13, first_name: "Sarah", last_name: "Blanking", email: "sblankingc@angelfire.com", gender: "Non-binary", login_date: "2/24/2020", age: 59 },
  { id: 14, first_name: "Willie", last_name: "Schaffler", email: "wschafflerd@tumblr.com", gender: "Genderfluid", login_date: "8/2/2021", age: 78 },
  { id: 15, first_name: "Addia", last_name: "Myrtle", email: "amyrtlee@cocolog-nifty.com", gender: "Female", login_date: "11/27/2020", age: 83 },
  { id: 16, first_name: "Kaitlynn", last_name: "William", email: "kwilliamf@microsoft.com", gender: "Genderfluid", login_date: "3/12/2021", age: 82 },
  { id: 17, first_name: "Catlee", last_name: "Andrews", email: "candrewsg@chron.com", gender: "Bigender", login_date: "3/13/2020", age: 49 },
  { id: 18, first_name: "Gothart", last_name: "Fitzsymonds", email: "gfitzsymondsh@bizjournals.com", gender: "Non-binary", login_date: "6/21/2020", age: 14 },
  { id: 19, first_name: "Harmony", last_name: "Deely", email: "hdeelyi@google.com.br", gender: "Genderqueer", login_date: "12/13/2019", age: 14 },
  { id: 20, first_name: "Miltie", last_name: "Newiss", email: "mnewissj@intel.com", gender: "Female", login_date: "6/20/2020", age: 49 }]

  const operators = [{ filter_Name: "contains" },
  { filter_Name: "equals" }]

  pageSizes = [5, 10, 15, 20, 50, 100]
  tableTitle = "Sample Title"

  const columns = useMemo(() => columnsData, [])
  const data = useMemo(() => rowsData, [])
  const defaultColumn = useMemo(() => { return { Filter: ColumnFilter } }, [])


  const [rowValue, setRowValue] = useState('')
  const [operatorValue, setOperatorValue] = useState('')
  const [headerValue, setHeaderValue] = useState('')

  const setOperatorValueHandler = (e) =>{    
    setOperatorValue(e.target.value)
  }
  const setRowValueHandler = (e) => {
    setRowValue(e.target.value)
  }
  const setHeaderValueHandler = e =>{
    setHeaderValue(e.target.value)
  } 
/*   const consoleDisplayHandler = () => {

    if(operatorValue=='contains'){
    if (rowsData.some(row => Object.keys(row).map(rowKey=>{row.rowKey==rowValue}))) {
      console.log("object found "  + rowValue + headerValue)
    } else {
      alert("Object not found.");
      console.log(headerValue)
    }}
    else{
      console.log(headerValue)
      console.log(rowsData.map(row => Object.keys(row)))
      console.log('no appropriate data')
    }

     if(rowsData.some(row=>row.id===document.getElementById('rowValue').innerHTML)) 
  } */

  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(5)
  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPage(0)
  }

  const { getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    state,
    setGlobalFilter,
    prepareRow,
    allColumns,
    getToggleHideAllColumnsProps,
    selectedFlatRows } = useTable({
      columns: columns, data: data, defaultColumn
    },
      useFilters,
      useGlobalFilter,
      useSortBy,
      useRowSelect,
      (hooks) => {
        hooks.visibleColumns.push((columns) => {
          return [
            {
              id: 'selection',
              Header: ({ getToggleAllRowsSelectedProps }) => (
                <Checkbox {...getToggleAllRowsSelectedProps()} />
              ),
              Cell: ({ row }) => (
                <Checkbox {...row.getToggleRowSelectedProps()} />
              )
            },
            ...columns
          ]
        })
      }
    )

  const { globalFilter } = state
  return (
    <>
      {/* uncomment for verification of columns enable disable code */}
      {/* <div>
        <Checkbox {...getToggleHideAllColumnsProps()} />Toggle All
      </div> */}

      <div style={{ display: "flex", justifyContent: "flex-between" }}>
        {tableTitle ? <h2>{tableTitle}</h2> : null}

      </div>

      <table{...getTableProps()}>
      {/* Header Content Displayed */}
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr{...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th{...column.getHeaderProps()} style={{ padding: "10px 15px 10px 15px" }}>
                  <div className="header-container">
                    <div className="align-header">{column.render('Header')}</div>
                    <div className="sort-filter-container">
                      <span {...column.getHeaderProps(column.getSortByToggleProps())}>
                        {column.isSorted ? (column.isSortedDesc ? <SouthIcon style={{ width: "20px", height: "20px" }} /> : <NorthIcon style={{ width: "20px", height: "20px" }} />) : <SwapVertIcon />}
                      </span>

                      <PopupState variant="popover" popupId="demo-popup-menu">
                        {(popupState) => (
                          <React.Fragment>
                            <button  {...bindTrigger(popupState)} className="header-options">
                              <MoreVertIcon style={{ width: "20px", height: "20px" }} />
                            </button>
                            <Menu {...bindMenu(popupState)}>
                              <div style={{ paddingLeft: "15px" }}>Column's</div>
                              {
                                allColumns.map(column => (
                                  <div key={column.id} style={{ padding: "0 20px 0 20px" }}>
                                    <label>
                                      <input type="checkbox" {...column.getToggleHiddenProps()} />
                                      {column.Header}
                                    </label>
                                  </div>
                                ))
                              }
                            </Menu>
                          </React.Fragment>
                        )}
                      </PopupState>
                    </div>
                  </div>
                  <div>{column.canFilter ? column.render('Filter') : null}</div>
                </th>
              ))}
            </tr>
          ))}
        </thead>
        {/* Table rows Displayed */}
        <tbody{...getTableBodyProps()} style={{ borderBottom: "1px solid #bbbbbb" }}>
          {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
            prepareRow(row)
            return (
              <tr{...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return <td style={{ border: "none" }} {...cell.getCellProps()}>{cell.render('Cell')}</td>
                })}
              </tr>
            )
          })}
        </tbody>

        {/* uncomment if you want to see header at footer section also <tfoot>
          {footerGroups.map((footerGroup) => (
            <tr{...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map((column) => (
                <td{...column.getFooterProps()}>{column.render('Footer')}</td>
              ))}
            </tr>
          ))}
        </tfoot> */}
      </table>

      <TablePagination
        rowsPerPageOptions={pageSizes}
        component="div"
        count={data.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage} />
    </>
  )
}
/* <button onClick={addDataHandler}>Add Data</button>
       {addData ? <div>
        <table>
          {headerGroups.map((headerGroup) => (
            <tr{...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th{...column.getHeaderProps()} style={{ padding: "10px 15px 10px 15px" }}>
                  <div className="header-container">
                    <input type="text" onChange={inputChangeHandler} placeholder={column.render('Header')} />
                  </div>
                </th>
              ))}</tr>
          ))}</table>
        <button type="submit" onClick={submitDataHandler}>Add</button>
      </div> : null}
      {addData ? <div>
        {addColumnData.map(addColumn=>{<input type="text" onChange={inputChangeHandler} placeholder={addColumn.accessor} />})}
        </div>:null
      } */

    /*   const setColumnHandler = (e) => {
        columnsData.map(column => {
          column.Header === e.target.value ? setColumnAccessor(column.accessor) : null
        })
      }
    
      const setValueHandler = (e) => {
        rowsData.map(row => { row.id === e.target.value ? setRowCellId(e.target.value) : null })
        console.log(e.target.value)
      } */

/* Filter Section code
      <div className="addData-container">

      <select name="headerValue" id="headerValue" onChange={setHeaderValueHandler}>
        {columnsData.map(column => {
          return (<option value={column.accessor}>{column.Header}</option>)
        })}
      </select>

      <select name="operatorValue" id="operatorValue" onChange={setOperatorValueHandler}>
        {operators.map(operations => {
          return (<option value={operations.filter_Name}>{operations.filter_Name}</option>)
        })}
      </select>

      <input type="text" id="rowValue" name="rowValue" onChange={setRowValueHandler} />
    </div>

    <button onClick={consoleDisplayHandler}>Filtered Data</button> */