export { Heading } from './heading';
export type { HeadingProps } from './heading';
