import React from 'react';
import { Welcome } from './welcome';

export const WelcomePage = () => <Welcome />;
