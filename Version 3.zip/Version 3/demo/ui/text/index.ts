export { Text } from './text';
export type { TextProps } from './text';
