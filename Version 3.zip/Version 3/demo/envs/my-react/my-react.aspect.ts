import { Aspect } from '@teambit/harmony';

export const MyReactAspect = Aspect.create({
  id: 'company.scope/envs/my-react',
});
